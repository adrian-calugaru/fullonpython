def equality(one,two,three):
	if one == two or two == three or one == three :
	 return True
	else:
	 return False

print(equality(2,3,int("5")))
